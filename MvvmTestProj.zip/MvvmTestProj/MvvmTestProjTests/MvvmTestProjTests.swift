//
//  MvvmTestProjTests.swift
//  MvvmTestProjTests
//
//  Created by office-it on 9/10/21.
//

import XCTest
@testable import MvvmTestProj

class MvvmTestProjTests: XCTestCase {
    
    var sut:PhotoListViewModel!
    var mockApiservice:MockService!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        mockApiservice = MockService()
        sut = PhotoListViewModel(apiservice: mockApiservice)
        
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func test_fecthdata_called() throws {
        
        //when
        sut.initFetch()
        
        //Assert
        
        XCTAssert(mockApiservice!.isfetchCalled)
        
    }
    
    func test_fetch_fail(){
        
        let error = APIError.permissionDenied
        
        //when
        
        sut.initFetch()
        mockApiservice.fetchFail(error: error)
        
        //Assert
        
        XCTAssertEqual(sut.alertMessage, error.rawValue)
    }
    
    func test_creat_cell_viewModel(){
        
        // given
        let photos = StubGenerator().stubPhotos()
        mockApiservice.compltePhotos = photos
        
        let expect = XCTestExpectation(description: "reload closure is called")
        
        sut.reloadTableViewClosure = { () in
            expect.fulfill()
        }
        
        // when
        sut.initFetch()
        mockApiservice.fetchSuccess()
        
        XCTAssertEqual(sut.numberOfCells, photos.count)
        
        wait(for: [expect], timeout: 1.0)
        
    }
    
    func test_loading_while_fetch(){
        var loading = false
        let expect = XCTestExpectation(description: "update loading status")
        
        sut.updateLoadingStatus = { [weak sut] in
            loading = sut!.isLoading
            expect.fulfill()
        }
        
        sut.initFetch()
        XCTAssertTrue(loading)
        
        mockApiservice.fetchSuccess()
        XCTAssertFalse(loading)
        
        wait(for: [expect], timeout: 1.0)
    }
    
    func test_user_pressed_sell_item(){
        
        goToFetchPhotoFinished()
        let index = IndexPath(row: 0, section: 0)
        
        sut.userPressed(at: index)
        XCTAssert(sut.isAllowSegue)
        XCTAssertNotNil(sut.selectedPhoto)
        
    }
    
    func test_user_pressed_Not_sell_item(){
        
        goToFetchPhotoFinished()
        let index = IndexPath(row: 4, section: 0)
        
        let expect = XCTestExpectation(description: "error description")
        sut.showAlertClosure = {[weak sut] in
            
            XCTAssertEqual(sut?.alertMessage, "This item is not for sale")
            expect.fulfill()
        }
        
        
        sut.userPressed(at: index)
        XCTAssertFalse(sut.isAllowSegue)
        XCTAssertNil(sut.selectedPhoto)
        
        wait(for:[expect],timeout: 2.0)
    }

    private func goToFetchPhotoFinished() {
        mockApiservice.compltePhotos = StubGenerator().stubPhotos()
        sut.initFetch()
        mockApiservice.fetchSuccess()
    }

}

class MockService:APIServiceProtocol{
    var isfetchCalled : Bool = false
    var compltePhotos:[Photo] = [Photo]()
    var completeBlock: ((Bool,[Photo],APIError?)->())!
    
    func fetchPopularPhoto(complete: @escaping (Bool, [Photo], APIError?) -> ()) {
        isfetchCalled = true
        completeBlock = complete
    }
    
    func fetchSuccess(){
        completeBlock(true,compltePhotos,nil)
    }
    
    func fetchFail(error:APIError){
        completeBlock(false,compltePhotos,error)
    }
}

class StubGenerator {
    func stubPhotos() -> [Photo] {
        let path = Bundle.main.path(forResource: "content", ofType: "json")!
        let data = try! Data(contentsOf: URL(fileURLWithPath: path))
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let photos = try! decoder.decode(Photos.self, from: data)
        return photos.photos
    }
}
